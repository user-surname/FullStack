package com.example.Conflict.Tracker.repository;

import com.example.Conflict.Tracker.model.Conflict;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConflictRepository extends CrudRepository<Conflict, Long> {
    Conflict findById(long id);

}

